import java.sql.Date;

public class request {
	private String priority;
	private String expireDay;
	private String status;
	
	public request(String priority, String expireDay, String status) {
		super();
		this.priority = priority;
		this.expireDay = expireDay;
		this.status = status;
	}
	
	
}
