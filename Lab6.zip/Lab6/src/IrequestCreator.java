
public interface IrequestCreator {
	
	request createRequest();

	
}
